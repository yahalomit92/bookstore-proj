import React from "react";

function NoPageFound() {
	return <div>404 PAGE NOT FOUND</div>;
}

export default NoPageFound;
